--------------------
Snippet: getPage
--------------------
Version: 1.2.5-pl
Released: April 6, 2022
Since: March 19, 2010
Author: Jason Coward <jason@modx.com>

A generic wrapper snippet for returning paged results and navigation from snippets that return limitable collections. This release requires MODX Revolution 2.1+.

Official Documentation:
https://docs.modx.com/current/en/extras/getpage
