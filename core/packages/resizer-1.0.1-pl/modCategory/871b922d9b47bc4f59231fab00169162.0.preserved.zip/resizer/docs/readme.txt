Resizer

A light-weight, modern image resizer for MODX.

Requires PHP 5.3.2+
This is a PHP class meant to be used in a snippet.  If you're looking for an
image-resizing snippet to use in your templates look at pThumb, which can
use Resizer.

Author: Jason Grant
Copyright 2013

Documentation, bug reports, feature requests:
https://github.com/oo12/Resizer