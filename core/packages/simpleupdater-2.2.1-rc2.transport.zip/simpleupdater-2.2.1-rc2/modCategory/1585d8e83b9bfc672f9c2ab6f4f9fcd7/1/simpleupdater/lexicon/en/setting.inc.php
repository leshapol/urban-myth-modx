<?php
$_lang['setting_simpleupdater.github_token'] = 'GitHub Token';
$_lang['setting_simpleupdater.github_token_desc'] = 'GitHub Personal access token to retrieve the MODX version without exceed the GitHub API Rate Limit https://github.com/settings/tokens';
$_lang['setting_simpleupdater.github_user'] = 'GitHub User';
$_lang['setting_simpleupdater.github_user_desc'] = 'Github user to retrieve the MODX version without exceeding the GitHub API Rate Limit';
$_lang['setting_simpleupdater.http_handler'] = 'HTTP Handler';
$_lang['setting_simpleupdater.http_handler_desc'] = 'HTTP handler type for retrieving the MODX version information (file_get_contents or curl)';
