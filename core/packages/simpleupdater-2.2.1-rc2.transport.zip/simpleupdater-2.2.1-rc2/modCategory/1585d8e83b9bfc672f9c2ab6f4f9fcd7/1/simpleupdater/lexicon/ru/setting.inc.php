<?php
$_lang['setting_simpleupdater.github_token'] = 'GitHub Token';
$_lang['setting_simpleupdater.github_token_desc'] = 'GitHub Personal access token, чтобы узнать последнюю версию MODX, не боясь исчерпать GitHub API Rate Limit: https://github.com/settings/tokens';
$_lang['setting_simpleupdater.github_user'] = 'GitHub User';
$_lang['setting_simpleupdater.github_user_desc'] = 'Пользователь GitHub';
$_lang['setting_simpleupdater.http_handler'] = 'HTTP Handler';
$_lang['setting_simpleupdater.http_handler_desc'] = 'Метод получения информации о версии MODX (file_get_contents или curl)';
