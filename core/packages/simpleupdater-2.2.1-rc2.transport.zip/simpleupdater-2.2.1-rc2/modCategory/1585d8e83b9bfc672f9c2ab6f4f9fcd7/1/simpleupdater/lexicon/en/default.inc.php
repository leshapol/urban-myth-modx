<?php

$_lang['simpleupdater'] = 'simpleUpdater';
$_lang['simpleupdater_intro_msg'] = 'Update the MODX core';
$_lang['simpleupdater_menu'] = 'simpleUpdater';
$_lang['simpleupdater_menu_desc'] = 'Update MODX';
$_lang['simpleupdater_no_update_available'] = 'No MODX core update available';
$_lang['simpleupdater_update'] = 'Update MODX';
$_lang['simpleupdater_update_start'] = 'Start update';
