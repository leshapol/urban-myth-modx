--------------------
Snippet: getResources
--------------------
Version: 1.7.1-pl
Released: June 5, 2023
Since: December 28, 2009
Author: Jason Coward <jason@opengeek.com>

A general purpose Resource listing and summarization snippet for MODX Revolution.

Official Documentation:
https://docs.modx.com/current/en/extras/getresources
