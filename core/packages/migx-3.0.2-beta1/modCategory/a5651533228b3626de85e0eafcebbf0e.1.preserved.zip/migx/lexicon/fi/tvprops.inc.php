<?php
/**
 * migx
 *
 * @package migx
 * @language fi
 * Vesa Särkelä 2019
 */
$_lang['mig.tabs'] = 'Lomake-välilehdet';
$_lang['mig.columns'] = 'Ruudukon sarakkeet';
$_lang['mig.btntext'] = '"Lisää kohde" korvaaminen';
$_lang['mig.previewurl'] = 'Esikatsele URL-osoitetta';
$_lang['mig.jsonvarkey'] = 'Esikatsele JsonVarKey';
$_lang['mig.configs'] = 'Kokoonpanot';
$_lang['mig.autoResourceFolders'] = 'Automaattiset resurssin kansiot';