--------------------
Extra: Ace
GitHub: https://github.com/modx-pro/modx-ace
--------------------
Since: March 29th, 2012
Author: Danil Kostin <danya.postfactum@gmail.com>
License: GNU GPLv2 (or later at your option)

Integrates Ace Code Editor into MODX Revolution.

Press Ctrl+Alt+H to see all available shortcuts.