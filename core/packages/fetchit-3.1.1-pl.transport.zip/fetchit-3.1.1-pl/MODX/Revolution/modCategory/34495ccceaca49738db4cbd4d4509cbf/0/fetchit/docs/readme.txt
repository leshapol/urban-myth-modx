--------------------
FetchIt
--------------------
Author: Gulomov Bakhtovar <gulomovcreative@gmail.com>
Original author: Vasily Naumkin <bezumkin@yandex.ru>
--------------------

A lightweight Extra for MODX Revolution for submitting forms with Fetch API.
