<?php

$_lang['fetchit_prop_form'] = 'Чанк с формой для отправки.';
$_lang['fetchit_prop_snippet'] = 'Сниппет, который будет обрабатывать указанную форму.';
$_lang['fetchit_prop_actionUrl'] = 'Коннектор для обработки запросов.';
$_lang['fetchit_prop_clearFieldsOnSuccess'] = 'Данный параметр отвечает за очистку данных формы после успешного ответа.';
