<?php

$_lang['fetchit_prop_form'] = 'Chunk with a form.';
$_lang['fetchit_prop_snippet'] = 'A snippet that will process the specified form.';
$_lang['fetchit_prop_actionUrl'] = 'Connector for request handling.';
$_lang['fetchit_prop_clearFieldsOnSuccess'] = 'This setting is responsible for clearing the form data after a successful response.';
