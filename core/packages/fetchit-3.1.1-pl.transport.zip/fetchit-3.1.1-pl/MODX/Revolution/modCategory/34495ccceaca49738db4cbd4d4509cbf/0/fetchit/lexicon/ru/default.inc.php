<?php
include_once 'setting.inc.php';

$_lang['fetchit'] = 'FetchIt';

$_lang['fetchit_submit'] = 'Отправить';
$_lang['fetchit_reset'] = 'Очистить';

$_lang['fetchit_label_name'] = 'Имя';
$_lang['fetchit_label_email'] = 'E-mail';
$_lang['fetchit_label_message'] = 'Сообщение';

$_lang['fetchit_err_action_ns'] = 'Не указан ключ формы (action).';
$_lang['fetchit_err_action_nf'] = 'Не могу найти указанный ключ формы (action).';
$_lang['fetchit_err_chunk_ns'] = 'Не указан чанк для обработки формы.';
$_lang['fetchit_err_chunk_nf'] = 'Не могу найти указанный чанк "[[+name]]" с формой.';
$_lang['fetchit_err_snippet_ns'] = 'Не указан сниппет для обработки формы.';
$_lang['fetchit_err_snippet_nf'] = 'Не могу найти указанный сниппет "[[+name]]" для обработки формы.';
$_lang['fetchit_err_has_errors'] = 'Форма содержит ошибки';
$_lang['fetchit_success_submit'] = 'Форма успешно отправлена';
